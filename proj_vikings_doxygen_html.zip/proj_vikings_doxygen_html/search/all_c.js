var searchData=
[
  ['showlangskips',['showLangskips',['../main_8cpp.html#a046057401b5f0bbc7fa73033b4af92cc',1,'main.cpp']]]
];
