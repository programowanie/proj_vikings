var searchData=
[
  ['offence',['offence',['../classLands.html#a8053dd4859dbc87662e171696014a9f7',1,'Lands::offence()'],['../classLangskip.html#aa346a53246e52ee1b4c99a2dbc5e15d2',1,'Langskip::offence()']]]
];
