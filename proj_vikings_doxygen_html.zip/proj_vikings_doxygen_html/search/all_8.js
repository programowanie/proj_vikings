var searchData=
[
  ['n',['N',['../main_8cpp.html#a0240ac851181b84ac374872dc5434ee4',1,'main.cpp']]],
  ['name',['name',['../classLands.html#aa62b508d2c0e7d9cec12924965276eb5',1,'Lands']]]
];
