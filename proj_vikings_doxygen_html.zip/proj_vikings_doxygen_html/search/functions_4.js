var searchData=
[
  ['lands',['Lands',['../classLands.html#a6da51c7c0c3b2ec17cd91b526adcaed3',1,'Lands']]],
  ['langskip',['Langskip',['../classLangskip.html#ab164889e74a73feb30694995f0063bc0',1,'Langskip']]],
  ['langskiptype',['langskipType',['../classLangskip.html#abbb8deaea19155e8915f7f2dfcc6ac5b',1,'Langskip']]]
];
