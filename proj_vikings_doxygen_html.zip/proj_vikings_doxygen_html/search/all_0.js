var searchData=
[
  ['_5fbeastratio',['_beastRatio',['../classLangskip.html#a9a12c44cb3036c2ac5a9f909eb344ff8',1,'Langskip']]],
  ['_5fdefence',['_defence',['../classLands.html#aea168c2cf627273e799f74a4a59d3165',1,'Lands::_defence()'],['../classLangskip.html#a78c0cb3c15aa924b01d9abb82dfff619',1,'Langskip::_defence()']]],
  ['_5fhp',['_hp',['../classLands.html#a1afcca4d4c69820436605728df718e8a',1,'Lands::_hp()'],['../classLangskip.html#a1afcca4d4c69820436605728df718e8a',1,'Langskip::_hp()']]],
  ['_5flangskiptype',['_langskipType',['../classLangskip.html#a841c22c9c46564a442e89896fe4bb239',1,'Langskip']]],
  ['_5fname',['_name',['../classLands.html#a92749b8d4b3ef0c4b1d2a4532db9032e',1,'Lands']]],
  ['_5foffence',['_offence',['../classLands.html#a1078ba1bbc057cb9ed348c87dc66f34b',1,'Lands::_offence()'],['../classLangskip.html#afb4cb19c4aafe242a6d54f5177bf3dd7',1,'Langskip::_offence()']]]
];
