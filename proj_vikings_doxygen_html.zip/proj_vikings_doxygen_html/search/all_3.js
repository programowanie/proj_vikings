var searchData=
[
  ['defence',['defence',['../classLands.html#a3d6e48e69c85021ec97d1290e91984bd',1,'Lands::defence()'],['../classLangskip.html#af601b36f57cd2530bd1d0b78349e38da',1,'Langskip::defence()']]],
  ['description',['description',['../classLands.html#a166e44f3030115668a91a35ffb81ff11',1,'Lands::description()'],['../classLangskip.html#a166e44f3030115668a91a35ffb81ff11',1,'Langskip::description()']]]
];
