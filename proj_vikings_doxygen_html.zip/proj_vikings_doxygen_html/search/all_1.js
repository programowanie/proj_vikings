var searchData=
[
  ['beastratio',['beastRatio',['../classLands.html#a99b9ad029188395742f05dc32d08b212',1,'Lands::beastRatio()'],['../classLangskip.html#a99b9ad029188395742f05dc32d08b212',1,'Langskip::beastRatio()']]]
];
