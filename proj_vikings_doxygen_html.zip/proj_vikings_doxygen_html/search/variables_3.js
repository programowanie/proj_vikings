var searchData=
[
  ['power',['power',['../structparameter.html#a8b7526d9a10da831296ea386c56b9908',1,'parameter::power()'],['../structparameter2.html#a8b7526d9a10da831296ea386c56b9908',1,'parameter2::power()']]]
];
