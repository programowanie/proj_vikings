var searchData=
[
  ['hp',['hp',['../classLands.html#a0f52c6ebb68ff9b77d7128b327f5e260',1,'Lands::hp()'],['../classLangskip.html#a0f52c6ebb68ff9b77d7128b327f5e260',1,'Langskip::hp()']]]
];
